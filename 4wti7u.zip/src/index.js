import "./styles.css";

document.getElementById("app").innerHTML = `
<center>
<b><h1>Ha <span style="color: red">Ha</span>.</h1></b>

<img
  src="https://media.tenor.com/SSY2V0RrU3IAAAAd/rick-roll-rick-rolled.gif"
/>
<audio controls autoplay>
<source src="Never gonna give you up.mp3" type="audio/mpeg" />
<br>
<br>
</audio>

`;
