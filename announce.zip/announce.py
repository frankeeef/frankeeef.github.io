import requests 
import time

url = "https://discord.com/api/webhooks/1079713282862092359/yG0H_f4HNE9OxGZDq_GkMafZmKL6h3FrOBWc1TGENC6kVJc95NnV-gha4hnHhR-urXch"
data = {
    "content" : "Session Reminder (@everyone)"
}

data["embeds"] = [
    {
        "description" : "Today's Session has ended. See you tommorow!",
        "title" : "Session Notice"
    }
]

result = requests.post(url, json = data)

try:
    result.raise_for_status()
except requests.exceptions.HTTPError as err:
    print(err)
else:
    print("Payload delivered successfully, code {}.".format(result.status_code))